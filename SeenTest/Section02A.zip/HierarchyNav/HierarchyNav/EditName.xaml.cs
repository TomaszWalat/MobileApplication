﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using Xamarin.Forms;
using Xamarin.Forms.Xaml;

namespace HierarchyNav
{
    [XamlCompilation(XamlCompilationOptions.Compile)]
    public partial class EditName : ContentPage
    {
        public EditName()
        {
            InitializeComponent();
        }

        private async void SaveButton_Clicked(object sender, EventArgs e)
        {
            await Navigation.PopAsync();
        }
    }
}